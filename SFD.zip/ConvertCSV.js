const fs = require("fs");

const csvDirPath = "D:/SFD/CSV";
const resultDirPath = "D:/SFD/RESULT";
const fileList = fs.readdirSync(csvDirPath);
fileList.forEach((fileName) => {
    const readFilePath = csvDirPath + "/" + fileName;
    let content = fs.readFileSync(readFilePath).toString();

    // content = content.replace(/<style>(.*?)<(\/?)style>/gi, "");
    // content = content.replace(/<head>(.*?)<(\/?)head>/gi, "");
    // content = content.replace(/<HEAD>(.*?)<(\/?)HEAD>/gi, "");

    // content = content.replace(/<(\/style|style)([^>]*)>/gi, "");
    // content = content.replace(/(<([^>]+)>)/ig, "");
    // content = content.replace(/<style[^>]*>.*<\/style>/ig, "");
    // content = content.replace(/<(\/)?([a-zA-Z]*)(\s[a-zA-Z]*=[^>]*)?(\s)*(\/)?>/ig, "");

    content = content.replace(/\n/g, "");

    console.log(content);


    const resultFilePath = resultDirPath + "/" + fileName;

    fs.writeFileSync(resultFilePath, content);
});





